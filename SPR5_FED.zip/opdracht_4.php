
<!DOCTYPE html> 
<html lang="en">
<head>

</head>
<body>
<?php 

$voornaam = "Mark";
$achternaam = "Rutte";

echo "$voornaam $achternaam<br>";

$voornaam = "Wim-Lex";
$achternaam = "van Oranje Nassau";

echo "$voornaam $achternaam<br";

?>
</body>
</html>