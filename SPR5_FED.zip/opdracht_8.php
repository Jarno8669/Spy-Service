<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
    <?php
$dagen = array("maandag", "dinsdag", "woensdag", "donderdag", "vrijdag", "zaterdag", "zondag");
echo var_dump($dagen) . "<br>";

$dagen = array("maandag", "dinsdag", "woensdag", "donderdag", "vrijdag", "zaterdag", "zondag");
print_r($dagen);

    ?>
</body>
</html>