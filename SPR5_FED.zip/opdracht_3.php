<!DOCTYPE html> 
<html lang="en">
<head>

</head>
<body>
<?php 
echo "Hallo allemaal!";

?>
</body>
</html>